﻿namespace Mastermind
{
    partial class frmMastermind
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMastermind));
            this.lblDirections = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblHint = new System.Windows.Forms.Label();
            this.lblGuess = new System.Windows.Forms.Label();
            this.pnlHint = new System.Windows.Forms.Panel();
            this.pnlGuess = new System.Windows.Forms.Panel();
            this.btnRules = new System.Windows.Forms.Button();
            this.lblDifficulty = new System.Windows.Forms.Label();
            this.cbxDifficulty = new System.Windows.Forms.ComboBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnRetry = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblTime = new System.Windows.Forms.Label();
            this.btnREADY = new System.Windows.Forms.Button();
            this.lblColor = new System.Windows.Forms.Label();
            this.lblSolution = new System.Windows.Forms.Label();
            this.pnlSolution = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCheck = new System.Windows.Forms.Button();
            this.colorList = new System.Windows.Forms.ImageList(this.components);
            this.hintList = new System.Windows.Forms.ImageList(this.components);
            this.tmrClock = new System.Windows.Forms.Timer(this.components);
            this.btnLeaderboard = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDirections
            // 
            this.lblDirections.AutoSize = true;
            this.lblDirections.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDirections.Location = new System.Drawing.Point(12, 9);
            this.lblDirections.Name = "lblDirections";
            this.lblDirections.Size = new System.Drawing.Size(273, 26);
            this.lblDirections.TabIndex = 0;
            this.lblDirections.Text = "Before you begin please click the Game Rules.\r\nSelect a difficulty, and click REA" +
    "DY.";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(376, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(114, 20);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Mastermind";
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.BackColor = System.Drawing.Color.Transparent;
            this.lblHint.Location = new System.Drawing.Point(434, 31);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(57, 13);
            this.lblHint.TabIndex = 12;
            this.lblHint.Text = "Hint Board";
            // 
            // lblGuess
            // 
            this.lblGuess.AutoSize = true;
            this.lblGuess.BackColor = System.Drawing.Color.Transparent;
            this.lblGuess.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblGuess.Location = new System.Drawing.Point(269, 31);
            this.lblGuess.Name = "lblGuess";
            this.lblGuess.Size = new System.Drawing.Size(68, 13);
            this.lblGuess.TabIndex = 11;
            this.lblGuess.Text = "Guess Board";
            // 
            // pnlHint
            // 
            this.pnlHint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlHint.Location = new System.Drawing.Point(430, 37);
            this.pnlHint.Margin = new System.Windows.Forms.Padding(2);
            this.pnlHint.Name = "pnlHint";
            this.pnlHint.Size = new System.Drawing.Size(156, 468);
            this.pnlHint.TabIndex = 10;
            // 
            // pnlGuess
            // 
            this.pnlGuess.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGuess.Location = new System.Drawing.Point(265, 37);
            this.pnlGuess.Margin = new System.Windows.Forms.Padding(2);
            this.pnlGuess.Name = "pnlGuess";
            this.pnlGuess.Size = new System.Drawing.Size(156, 468);
            this.pnlGuess.TabIndex = 9;
            // 
            // btnRules
            // 
            this.btnRules.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRules.Location = new System.Drawing.Point(15, 115);
            this.btnRules.Margin = new System.Windows.Forms.Padding(2);
            this.btnRules.Name = "btnRules";
            this.btnRules.Size = new System.Drawing.Size(98, 30);
            this.btnRules.TabIndex = 15;
            this.btnRules.Text = "Game Rules";
            this.btnRules.UseVisualStyleBackColor = true;
            this.btnRules.Click += new System.EventHandler(this.btnRules_Click);
            // 
            // lblDifficulty
            // 
            this.lblDifficulty.AutoSize = true;
            this.lblDifficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDifficulty.Location = new System.Drawing.Point(12, 65);
            this.lblDifficulty.Name = "lblDifficulty";
            this.lblDifficulty.Size = new System.Drawing.Size(101, 13);
            this.lblDifficulty.TabIndex = 14;
            this.lblDifficulty.Text = "Select Difficulty:";
            // 
            // cbxDifficulty
            // 
            this.cbxDifficulty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxDifficulty.FormattingEnabled = true;
            this.cbxDifficulty.Items.AddRange(new object[] {
            "Easy",
            "Medium",
            "Hard"});
            this.cbxDifficulty.Location = new System.Drawing.Point(119, 62);
            this.cbxDifficulty.Name = "cbxDifficulty";
            this.cbxDifficulty.Size = new System.Drawing.Size(84, 21);
            this.cbxDifficulty.TabIndex = 13;
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(172, 283);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 20;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnRetry
            // 
            this.btnRetry.Location = new System.Drawing.Point(12, 283);
            this.btnRetry.Name = "btnRetry";
            this.btnRetry.Size = new System.Drawing.Size(75, 23);
            this.btnRetry.TabIndex = 19;
            this.btnRetry.Text = "Retry";
            this.btnRetry.UseVisualStyleBackColor = true;
            this.btnRetry.Click += new System.EventHandler(this.btnRetry_Click);
            // 
            // btnOK
            // 
            this.btnOK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnOK.Enabled = false;
            this.btnOK.ImageKey = "(none)";
            this.btnOK.Location = new System.Drawing.Point(92, 283);
            this.btnOK.Margin = new System.Windows.Forms.Padding(2);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 24);
            this.btnOK.TabIndex = 16;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(104, 357);
            this.lblTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(42, 13);
            this.lblTime.TabIndex = 22;
            this.lblTime.Text = "Time: 0";
            // 
            // btnREADY
            // 
            this.btnREADY.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnREADY.Location = new System.Drawing.Point(146, 115);
            this.btnREADY.Name = "btnREADY";
            this.btnREADY.Size = new System.Drawing.Size(85, 30);
            this.btnREADY.TabIndex = 23;
            this.btnREADY.Text = "READY";
            this.btnREADY.UseVisualStyleBackColor = true;
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColor.Location = new System.Drawing.Point(80, 166);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(99, 15);
            this.lblColor.TabIndex = 24;
            this.lblColor.Text = "Color Panel";
            // 
            // lblSolution
            // 
            this.lblSolution.AutoSize = true;
            this.lblSolution.BackColor = System.Drawing.Color.Transparent;
            this.lblSolution.Location = new System.Drawing.Point(60, 459);
            this.lblSolution.Name = "lblSolution";
            this.lblSolution.Size = new System.Drawing.Size(75, 13);
            this.lblSolution.TabIndex = 26;
            this.lblSolution.Text = "Solution Panel";
            // 
            // pnlSolution
            // 
            this.pnlSolution.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSolution.Location = new System.Drawing.Point(56, 466);
            this.pnlSolution.Margin = new System.Windows.Forms.Padding(2);
            this.pnlSolution.Name = "pnlSolution";
            this.pnlSolution.Size = new System.Drawing.Size(156, 39);
            this.pnlSolution.TabIndex = 25;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(12, 184);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(229, 37);
            this.panel1.TabIndex = 27;
            // 
            // btnCheck
            // 
            this.btnCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheck.Location = new System.Drawing.Point(69, 237);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(120, 23);
            this.btnCheck.TabIndex = 28;
            this.btnCheck.Text = "Check My Guess";
            this.btnCheck.UseVisualStyleBackColor = true;
            // 
            // colorList
            // 
            this.colorList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("colorList.ImageStream")));
            this.colorList.TransparentColor = System.Drawing.Color.Transparent;
            this.colorList.Images.SetKeyName(0, "Red.png");
            this.colorList.Images.SetKeyName(1, "Blue.png");
            this.colorList.Images.SetKeyName(2, "Green.png");
            this.colorList.Images.SetKeyName(3, "Yellow.png");
            this.colorList.Images.SetKeyName(4, "Purple.png");
            this.colorList.Images.SetKeyName(5, "pink.png");
            this.colorList.Images.SetKeyName(6, "Teal.png");
            this.colorList.Images.SetKeyName(7, "Orange.png");
            this.colorList.Images.SetKeyName(8, "LightGreen.png");
            this.colorList.Images.SetKeyName(9, "DarkPink.png");
            this.colorList.Images.SetKeyName(10, "LightBlue.png");
            // 
            // hintList
            // 
            this.hintList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("hintList.ImageStream")));
            this.hintList.TransparentColor = System.Drawing.Color.Transparent;
            this.hintList.Images.SetKeyName(0, "Clear.png");
            this.hintList.Images.SetKeyName(1, "White.png");
            this.hintList.Images.SetKeyName(2, "Black.png");
            // 
            // tmrClock
            // 
            this.tmrClock.Interval = 1000;
            // 
            // btnLeaderboard
            // 
            this.btnLeaderboard.Location = new System.Drawing.Point(92, 319);
            this.btnLeaderboard.Name = "btnLeaderboard";
            this.btnLeaderboard.Size = new System.Drawing.Size(75, 23);
            this.btnLeaderboard.TabIndex = 29;
            this.btnLeaderboard.Text = "Leaderboard";
            this.btnLeaderboard.UseVisualStyleBackColor = true;
          //  this.btnLeaderboard.Click += new System.EventHandler(this.btnLeaderboard_Click);
            // 
            // frmMastermind
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 527);
            this.Controls.Add(this.btnLeaderboard);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblSolution);
            this.Controls.Add(this.pnlSolution);
            this.Controls.Add(this.lblColor);
            this.Controls.Add(this.btnREADY);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnRetry);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnRules);
            this.Controls.Add(this.lblDifficulty);
            this.Controls.Add(this.cbxDifficulty);
            this.Controls.Add(this.lblHint);
            this.Controls.Add(this.lblGuess);
            this.Controls.Add(this.pnlHint);
            this.Controls.Add(this.pnlGuess);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblDirections);
            this.Name = "frmMastermind";
            this.Text = "Mastermind";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDirections;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Label lblGuess;
        private System.Windows.Forms.Panel pnlHint;
        private System.Windows.Forms.Panel pnlGuess;
        private System.Windows.Forms.Button btnRules;
        private System.Windows.Forms.Label lblDifficulty;
        private System.Windows.Forms.ComboBox cbxDifficulty;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRetry;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Button btnREADY;
        private System.Windows.Forms.Label lblColor;
        private System.Windows.Forms.Label lblSolution;
        private System.Windows.Forms.Panel pnlSolution;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.ImageList colorList;
        private System.Windows.Forms.ImageList hintList;
        private System.Windows.Forms.Timer tmrClock;
        private System.Windows.Forms.Button btnLeaderboard;
    }
}